/**
 * Click2Pickup - Public JavaScript
 */

jQuery(document).ready(function($) {
    // Scripts públicos serão adicionados conforme necessário
    console.log('Click2Pickup Public JS Loaded');
});