/**
 * Scripts administrativos do Click2Pickup
 */

jQuery(document).ready(function($) {
    // Placeholder para futuros scripts
    console.log('Click2Pickup Admin loaded');
});